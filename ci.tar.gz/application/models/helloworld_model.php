
$hostname="mysql15.000webhost.com";
$username="a3919920_root";
$password="Aa211085";
$dbname="a3919920_dokimh";
$usertable="video";
$yourfield1 = "subject";
