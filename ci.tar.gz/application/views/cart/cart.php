    <?php error_reporting(0);
    if(!$this->cart->contents()):  
        echo 'You don\'t have any items yet.';  
    else:  
    ?>  
    <?php echo form_open('cart/update_cart'); ?>  
    <table width="650px" cellpadding="0" cellspacing="0">  
        <thead>  
            <tr>  
                <td>Qty</td>  
                <td>Item Description</td>  
                <td>Item Price</td>  
                <td>Sub-Total</td>
                <td>Status</td>
                <td style="color:blue">In-Stock(after purchasing)</td>
            </tr>  
        </thead>  
        <tbody>  
            <?php $i = 1; ?>  
            <?php foreach($this->cart->contents() as $items): ?>  
            <?php echo form_hidden('rowid[]', $items['rowid']); ?>  
            <tr <?php if($i&1){ echo 'class="alt"'; }?>>  
                <td>  
                    <?php echo $items['qty']; ?>  
                </td>  
                <td><?php echo $items['name']; ?></td>  
                <td>&euro;<?php echo $this->cart->format_number($items['price']); ?></td>  
                <td>&euro;<?php echo $this->cart->format_number($items['subtotal']); ?></td>
                <td style="color:red;"><?php if($items['stock']-$items['qty']<0){
                $items['qty']=0;
                
                echo "Out of stock";
                 print ("<html><script language='JavaScript'>alert('Check status:out of stock,Please change Quantity of product! '),exit</script></html>");
                }else{ echo "In-stock"; ?></td>
               
                <td id="st"><b><?php echo $items['stock']-$items['qty']; ?></b></td>
                <?php    } ?>
             
            <?php $i++; ?>  
            <?php endforeach; ?>  
            <tr>  
                <td</td>  
                <td></td>  
                <td><strong>Total</strong></td>  
                <td style="color:red">&euro;<?php echo $this->cart->format_number($this->cart->total()); ?></td>  
            </tr>  
        </tbody>  
    </table>  
    <p><?php echo form_submit('', 'Update your Cart'); echo anchor('cart/empty_cart', 'Empty Cart', 'class="empty"');?></p>  
    <p><small>If the quantity is set to zero, the item will be removed from the cart.</small></p>  
    <?php  
    echo form_close();  
    endif;  
    ?>  